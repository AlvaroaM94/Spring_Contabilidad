package uia.com.api.ContabilidadUIA.modelo;

import java.util.ArrayList;
import java.util.HashMap;

import uia.com.api.ContabilidadUIA.modelo.clientes.InfoUIA;
import uia.com.api.ContabilidadUIA.modelo.gestor.DecoradorProveedores;
import uia.com.api.ContabilidadUIA.modelo.gestor.Gestor;
import uia.com.api.ContabilidadUIA.modelo.proveedores.Proveedor;

public class ClientesRepositorio {
		
	    public Gestor contabilidad;
		public DecoradorProveedores gestorProveedores = null;		
		public Proveedor proveedor = null;
		public String clienteId="";
		private ArrayList<InfoUIA> listaProveedores;

		public ClientesRepositorio()
		{
		 contabilidad = new Gestor("C:\\Users\\alvar\\Downloads\\ContabilidadUIA (1)\\ContabilidadUIA\\target\\ListaProveedores.json");		
		 gestorProveedores = new DecoradorProveedores(contabilidad, "proveedor");		 
		 gestorProveedores.Print();
		 listaProveedores = gestorProveedores.getLista();
		}
		
	


		public DecoradorProveedores getGestorProveedores() {
			return gestorProveedores;
		}

		public void setGestorProveedores(DecoradorProveedores gestorProveedores) {
			this.gestorProveedores = gestorProveedores;
		}


	
		public void borraCliente(String clienteId) {
			// TODO Auto-generated method stub
			
		}
		
		
		public Object getProveedor(String clienteId) {
			proveedor = (Proveedor) contabilidad.busca(clienteId);
			return proveedor;
		}



		public InfoUIA agregaCatalogo(InfoUIA newCliente) {
			
			HashMap<String, InfoUIA> p= new HashMap();
			p.put(newCliente.getName(), newCliente);
			return gestorProveedores.agregaCatalogo(p);
		
		}
		

		public ArrayList<InfoUIA> getListaProveedores() {
			return listaProveedores;
		}




		public void setListaProveedores(ArrayList<InfoUIA> listaProveedores) {
			this.listaProveedores = listaProveedores;
		}
	
}
