package uia.com.api.ContabilidadUIA.modelo.gestor;

import java.util.HashMap;
import java.util.Map;

import uia.com.api.ContabilidadUIA.modelo.clientes.InfoUIA;

public class DecoradorProveedores extends Decorador {
	
	public DecoradorProveedores(IGestor gestor, String tipo)
	{
		super(gestor, tipo);
	}
	
	
	public DecoradorProveedores()
	{		
	}
	
	public void validaProveedores()
	{
		super.Print();
	}


	public InfoUIA agregaCatalogo(HashMap<String, InfoUIA> p) {
		// TODO Auto-generated method stub
		return null;
	}

	





}
