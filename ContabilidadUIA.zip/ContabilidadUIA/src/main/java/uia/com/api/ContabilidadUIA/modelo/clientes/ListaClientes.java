package uia.com.api.ContabilidadUIA.modelo.clientes;

import java.util.ArrayList;



public class ListaClientes extends ListaInfoUIA
{

	public ListaClientes() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}


