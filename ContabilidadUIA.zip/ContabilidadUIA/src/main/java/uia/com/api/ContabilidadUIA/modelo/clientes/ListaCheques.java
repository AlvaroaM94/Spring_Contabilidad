package uia.com.api.ContabilidadUIA.modelo.clientes;

public class ListaCheques {

	public ListaCheques() {
		super();
		// TODO Auto-generated constructor stub
	}
}
