package uia.com.api.ContabilidadUIA.modelo.clientes;

public interface IInfoUIA {
   public void setType(String tipo);
   public String getType();
}
