package uia.com.api.ContabilidadUIA.modelo.clientes;

public class ListaNotaDebito extends ListaInfoUIA{
	public ListaNotaDebito() {
		super();
		// TODO Auto-generated constructor stub
	}
}
